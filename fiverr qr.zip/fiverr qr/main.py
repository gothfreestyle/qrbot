import telebot
import qrcode
from urllib.request import urlopen
from telebot.util import antiflood
from io import BytesIO
from PIL import Image

TEMPLATE = Image.open("template.png")
QR_POS = (672, 461)

with open("token.txt") as file:
    TOKEN = file.read()

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=["start"])
def bot_start(message):
    bot.reply_to(message, "кинь дату")
    bot.register_next_step_handler(message, bot_data)

def bot_data(message):
    if not message.document:
        bot.send_message(message.chat.id, "пошел нахуй")
        return
    if not message.document.mime_type == "text/plain":
        bot.send_message(message.chat.id, "пошел нахуй")
        return
    
    try:
        data = urlopen(bot.get_file_url(message.document.file_id)).read().decode("utf-8").split("\n")
        for i in range(len(data)):
            if not data[i] == "":
                data[i] = data[i].split(" | ")
        data = data[:-1]
        for i in data:
            qr = qrcode.make(i[0]).resize((225,225))
            new_im = Image.new("RGB", TEMPLATE.size, (0,0,0))
            new_im.paste(TEMPLATE, (0,0))
            new_im.paste(qr, QR_POS)
            bio = BytesIO()
            bio.name = i[1] + ".png"
            new_im.save(bio)
            bio.seek(0)
            antiflood(bot.send_document, message.chat.id, bio, caption="Link: `" + "https://www.fiverr.com/inbox/" + i[1] + "`", parse_mode="MARKDOWN")
    except:
        bot.send_message(message.chat.id, "error")

bot.polling()
